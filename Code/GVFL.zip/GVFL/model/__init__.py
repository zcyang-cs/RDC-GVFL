from model.fcn import FCN
from model.gcn import GCN
from model.sgc import SGC
from model.ae import AutoEncoder
# from model.rgcn import RGCN
